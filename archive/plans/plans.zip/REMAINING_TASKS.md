# Оставшиеся задачи (Remaining Tasks)

**Дата:** 2026-05-06  
**Проект:** Latin Macronizer (Python → TypeScript/JavaScript Browser Edition)  
**Статус Morpheus интеграции:** ✅ Завершено (включено в основной pipeline)

---

## 📊 Текущий статус порта

| Компонент | Статус | Завершено |
|-----------|--------|-----------|
| Core tokenization | ✅ | 100% |
| DP alignment (alignMacronized) | ✅ | 100% |
| Candidate ranking | ✅ | 100% |
| WASM RFTagger | ✅ | 100% |
| WASM Morpheus (интеграция) | ✅ | 100% |
| Wordlist Engine (IndexedDB) | ✅ | 100% |
| Ending patterns | ✅ | 100% |
| Lemma engine | ✅ | 100% |
| Scansion engine | ❌ | 0% (не критично) |
| UI polish | 🔄 | 60% |

**Общая завершённость:** ~95% (без учёта scansion)

---

## ✅ Завершённые задачи (последние изменения)

1. **Morpheus WASM интеграция** — добавлен `WordlistEngine.ensureAnalyzed()` в `Macronizer.macronize()`
2. **`WordlistEngine.analyzeUnknownWords()`** — полная портированная логика из `wordlist.py::crunchwords()`
3. **`MorpheusAnalyzer`** — исправлен парсинг accented формы
4. **`test-algorithms-compare.html`** — обновлён для инициализации Morpheus и вызова `ensureAnalyzed()`
5. **Unit-тесты** — все 150 тестов проходят
6. **TypeScript сборка** — успешна (`npm run build`)

---

## ⏳ Следующие шаги (приоритетный порядок)

### 🔴 Высокий приоритет

#### 1. **Полная валидация с полным wordlist (33MB)**
**Что сделать:**
- Открыть `test-algorithms-compare.html` в браузере (Chrome/Firefox)
- Загрузить `latin_macronizer/macrons.txt` через кнопку "Auto-load" или file upload
- Дождаться загрузки в IndexedDB (~30–60 сек)
- Нажать "Run Test"
- Сравнить вывод с `dist/output.txt` (Python reference)

**Критерий успеха:** 100% совпадение символов (включая все macrons).

**Если есть расхождения:**
- Проверить консольные логи — включены debug-слова: `matrona`, `longissime`, `minime`, `sequana`, `eos`, `hi`
- Убедиться, что `ensureAnalyzed()` вызывается (лог `[Macronizer]` если добавить)
- Проверить, что Morpheus возвращает accented формы в underscore-нотации (например, `minim_e` → `minim_e`)

---

#### 2. **Обновление документации**
**Файлы:**
- `README-BROWSER.md` — добавить:
  - Раздел "Morpheus Integration" (batch analysis, `ensureAnalyzed`)
  - Подробности DP alignment и candidate ranking
  - Список всех опций (`domacronize`, `alsomaius`, `performutov`, `performitoj`, `markambigs`)
  - Инструкция по тестированию (`test-algorithms-compare.html`)
- `IMPLEMENTATION_SUMMARY.md` — обновить статус Morpheus на "Complete"
- `BROWSER_TODO.md` — пометить пункты про Morpheus как ✅

---

#### 3. **Индикатор прогресса загрузки wordlist**
**Текущее состояние:** `WordlistEngine.loadFromText()` принимает `onProgress(count)`, но UI не использует.

**Что добавить в `index.html` и `test-algorithms-compare.html`:**
- Элемент `<progress>` или текст "Loaded X/Y entries..."
- Обновлять в коллбэке `onProgress`

---

### 🟡 Средний приоритет

#### 4. **Unit-тесты для Morpheus интеграции**
**Нужно добавить в `tests/`:**
- `WordlistEngine.test.ts`:
  - `cleanLemma()` — проверка удаления `#`, `1`, пробелов, `-`, `^`, `_`
  - `ensureAnalyzed()` — мок Morpheus, проверка что missing слова анализируются
  - `analyzeUnknownWords()` — группировка по `(lemma, tag)`, выбор best accented
- `MorpheusAnalyzer.test.ts`:
  - `parseAnalysisLine()` — парсинг строки Morpheus, извлечение `accented`
  - `analysisToLdtTag()` — конвертация в LDT tag

---

#### 5. **Production build проверка**
```bash
npm run build:prod
```
- Убедиться, что `dist/` содержит минифицированные файлы
- Протестировать на простом HTTP-сервере (без Vite dev middleware):
  ```bash
  npx serve dist
  ```
- Открыть `index.html` и проверить работу

---

#### 6. **Производительность Morpheus batch**
**Проблема:** `MorpheusAnalyzer.analyzeBatch()` вызывает `analyze()` синхронно в цикле. Для 100+ неизвестных слов может быть медленно.

**Возможные улучшения:**
- Web Worker для параллельного анализа
- Кэширование результатов Morpheus (уже есть в IndexedDB, но `ensureAnalyzed` проверяет перед вызовом)
- Лимитировать batch size (например, 50 слов за раз, чтобы не блокировать UI)

**Текущая оценка:** Morpheus WASM ~1000 токенов/сек, так что 100 слов = 0.1 сек — приемлемо.

---

### 🟢 Низкий приоритет / Опционально

#### 7. **Scansion engine (meter analysis)**
- Порт `meters.py` и `scansion.py` — сложная логика, нишевая функция
- Рекомендация: вынести в отдельный модуль `scansion/`, не в core macronizer

#### 8. **Fallback JS tagger**
- `FallbackTagger` уже реализован, но не используется по умолчанию
- Можно сделать опцию `useWasm: false` для браузеров без WASM

#### 9. **Service Worker для кэширования**
- Кэшировать `public/wasm/*` (13MB) и `src/data/*.json` (~400KB)
- PWA: `manifest.json`, `service-worker.js`

#### 10. **Accessibility & i18n**
- ARIA labels для кнопок
- Keyboard navigation
- Мультиязычный UI (английский/латинский)

---

## 🐛 Потенциальные баги (наблюдения)

### 1. `MorpheusAnalyzer.analyzeBatch()` — синхронный цикл
```typescript
analyzeBatch(words: string[]): MorpheusAnalysis[] {
  const results: MorpheusAnalysis[] = [];
  for (const word of words) {
    results.push(this.analyze(word, options));  // синхронный вызов
  }
  return results;
}
```
**Влияние:** Блокирует UI при анализе >100 слов.  
**Решение:** Обернуть в `Promise.all()` или использовать Web Worker.

### 2. `WordlistEngine.ensureAnalyzed()` — отсутствует лимит параллелизма
Если `unknownWords` содержит 1000 слов, `analyzeUnknownWords()` вызовет Morpheus 1000 раз синхронно.  
**Рекомендация:** Добавить `batchSize` (например, 100) и `setTimeout` между батчами, чтобы не блокировать main thread.

### 3. `MorpheusAnalyzer.parseAnalysisLine()` — обработка `stem`
Сейчас `stem = accented` (если нет запятой). В Python `morpheus_to_parses` использует `stem` неявно. Проверить, нужен ли `stem` где-либо. Сейчас не используется.

---

## 📋 Чек-лист финальной проверки

- [ ] **Full wordlist validation** — `test-algorithms-compare.html` с 33MB файлом
- [ ] **`index.html` UI** — Morpheus инициализируется, `ensureAnalyzed` вызывается
- [ ] **README-BROWSER.md** — обновлена
- [ ] **Unit-тесты** — добавлены для Morpheus/WordlistEngine
- [ ] **Production build** — `npm run build:prod` работает
- [ ] **Performance** — нет лагов при анализе неизвестных слов
- [ ] **No console errors** — в браузере при полном проходе

---

## 🎯 Критерии "Готово к релизу"

1. ✅ **100% совпадение с Python** на тестовом корпусе (Caesar 1.1)
2. ✅ **Все unit-тесты** проходят (включая новые для Morpheus)
3. ✅ **Документация** актуальна
4. ✅ **UI** показывает прогресс загрузки wordlist
5. ✅ **Production build** протестирован на статическом сервере

---

**Следующий шаг:** Запустить `test-algorithms-compare.html` в браузере и провести полную валидацию. Если всё совпадает — проект считается завершённым (95% → 100%, исключая scansion).
