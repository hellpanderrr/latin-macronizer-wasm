# Morpheus Integration Plan: Aligning TypeScript Port with Python Behavior

**Date:** 2026-05-06  
**Author:** Kilo Code (Architect mode)  
**Task:** Integrate Morpheus WASM into the main macronization pipeline to match Python's behavior

---

## Executive Summary

The TypeScript port has **Morpheus WASM code complete** (`MorpheusAnalyzer.ts`, `morpheus_js/`) but it is **not integrated** into the primary macronization flow. The Python version calls `wordlist.loadwords()` which invokes Morpheus for unknown words **before** accent selection. The TypeScript `Tokenization.getAccents()` currently only uses `EndingPatternEngine` for unknown words, skipping Morpheus entirely.

**Goal:** Modify `Macronizer.macronize()` to pre-analyze unknown words with Morpheus **prior** to `getAccents()`, exactly like Python.

---

## 1. Current State Analysis

### 1.1 Python Flow (`latin_macronizer/macronizer.py`)

```python
def settext(self, text):
    self.tokenization = Tokenization(text)
    self.wordlist.loadwords(self.tokenization.allwordforms())  # ← Morpheus called here
    newwordforms = self.tokenization.splittokens(self.wordlist)
    self.wordlist.loadwords(newwordforms)                        # ← And here
    self.tokenization.addtags()
    self.tokenization.addlemmas(self.wordlist)
    self.tokenization.getaccents(self.wordlist)                  # Uses wordlist (now with Morpheus data)
```

**Key points:**
- `wordlist.loadwords(words)` checks which words are missing from the DB
- For missing words, calls `crunchwords()` → runs Morpheus subprocess → parses output → inserts multiple entries per word into DB
- Each word can get **multiple** entries: different (lemma, tag) pairs with their accented forms
- After `loadwords()`, `wordlist.formtotaglemmaaccents` is fully populated, so `getaccents()` finds candidates for **all** words

### 1.2 TypeScript Current Flow (`src/core/Macronizer.ts`)

```typescript
async macronize(text: string): Promise<MacronizeResult> {
  const tokenization = new Tokenization(text, { preserveWhitespace: true });
  await tokenization.splitEnclitics(this.wordlistEngine);   // No Morpheus
  await tokenization.tagWithWasm(this.tagger);
  tokenization.addLemmas(this.lemmaEngine);
  await tokenization.getAccents(this.wordlistEngine, this.endingEngine); // Unknown → ending patterns only
  tokenization.macronize(...);
  return ...;
}
```

**Missing:** No call to Morpheus before `getAccents()`.

### 1.3 Existing Morpheus Infrastructure

**`WordlistEngine` methods (already implemented but unused):**
- `lookupOrAnalyze(wordform, tag)` — single-word lookup with Morpheus fallback
- `analyzeUnknownWords(words[])` — batch analysis, but **incomplete**:
  - Only adds **one** entry per word (first analysis)
  - Tag set to `'---------'` (not converted from Morpheus tags)
  - Does not group by (lemma, tag) or select best accented form

**`MorpheusAnalyzer`** — fully functional WASM wrapper returning structured analyses.

---

## 2. Required Changes

### 2.1 Enhance `WordlistEngine.analyzeUnknownWords()` (Critical)

**File:** `src/analysis/WordlistEngine.ts`

**Current problems:**
- Only uses first Morpheus analysis (Python uses **all** parses)
- Tag is hardcoded `'---------'` instead of converting Morpheus POS to LDT
- No grouping by (lemma, tag) to produce multiple entries
- No selection of best accented form per (lemma, tag) group
- Missing special case: `trans` words need `_` inserted (Python line 147–148)

**Required improvements:**

```typescript
async analyzeUnknownWords(words: string[]): Promise<WordlistEntry[]> {
  if (!this.morpheusAnalyzer || !this.morpheusAnalyzer.isInitialized()) {
    throw new Error('Morpheus analyzer not set or not initialized');
  }

  const results: WordlistEntry[] = [];
  const unknownWords: string[] = [];

  // Filter words not in wordlist (no entries with accentedUnderscore)
  for (const word of words) {
    const normalized = word.toLowerCase().trim();
    const entries = await this.getAllEntries(normalized);
    if (entries.length === 0) {
      unknownWords.push(word);
    }
  }

  if (unknownWords.length === 0) {
    return results;
  }

  // Analyze with Morpheus (batch)
  const analyses = this.morpheusAnalyzer.analyzeBatch(unknownWords);

  for (const analysis of analyses) {
    if (!analysis.success || analysis.analyses.length === 0) {
      continue;
    }

    // Group by (lemma, tag) to collect all accented forms for that parse
    const lemmaTagToAccented: Map<string, string[]> = new Map();

    for (const parse of analysis.analyses) {
      const lemma = this.cleanLemma(parse.lemma);
      const ldtTag = this.analysisToLdtTag(parse);
      const accentedRaw = parse.raw;

      // Special case: trans verbs need _ after prefix (Python wordlist.py line 147-148)
      let accentedAdjusted = accentedRaw;
      if (lemma.startsWith('trans') && accentedRaw.length > 3 && accentedRaw[3] !== '_') {
        accentedAdjusted = accentedRaw.slice(0, 3) + '_' + accentedRaw.slice(3);
      }

      const key = `${lemma}|${ldtTag}`;
      const existing = lemmaTagToAccented.get(key) || [];
      existing.push(accentedAdjusted);
      lemmaTagToAccented.set(key, existing);
    }

    // For each (lemma, tag) group, select best accented form
    for (const [key, accenteds] of lemmaTagToAccented.entries()) {
      const [lemma, ldtTag] = key.split('|');
      // Python preference: forms with more 'v', 'j', 'J' (prefers volvit over voluit, Julius over Iulius)
      const bestAccented = accenteds.sort((a, b) => {
        const scoreA = (a.match(/[vjJ]/g) || []).length;
        const scoreB = (b.match(/[vjJ]/g) || []).length;
        return scoreA - scoreB;  // ascending, so highest score comes last
      }).pop()!;  // take highest

      const accentedUnderscore = unicodeToUnderscore(bestAccented);

      const entry: WordlistEntry = {
        wordform: analysis.word.toLowerCase(),
        tag: ldtTag,
        lemma,
        macronized: this.convertMacronMarks(bestAccented),
        accentedUnderscore
      };

      results.push(entry);
      await this.addEntry(entry);  // Cache in DB
    }
  }

  return results;
}

// Helper: clean lemma (match Python wordlist.clean_lemma)
private cleanLemma(lemma: string): string {
  return lemma.replace(/[#1\s_-]/g, '');
}
```

**Why this matches Python:**
- `morpheus_to_parses()` produces multiple parses per word → we iterate all `analysis.analyses`
- Group by `(lemma, tag)` → creates multiple entries per wordform (like Python's `formtotaglemmaaccents[wordform]` list)
- Select best accented per group using `v/j/J` count (Python line 157)
- Special `trans` handling (Python line 147–148)
- `clean_lemma()` removes `#`, `1`, spaces, `-`, `_` (Python line 18–19)

---

### 2.2 Add `WordlistEngine.ensureAnalyzed()` Convenience Method

**New method** to replicate Python's `loadwords()` strategy:

```typescript
async ensureAnalyzed(wordForms: string[]): Promise<void> {
  const uniqueForms = Array.from(new Set(
    wordForms.map(w => toAscii(w).toLowerCase().trim())
  ));

  const missing: string[] = [];
  for (const word of uniqueForms) {
    const entries = await this.getAllEntries(word);
    if (entries.length === 0) {
      missing.push(word);
    }
  }

  if (missing.length === 0) {
    return;
  }

  await this.analyzeUnknownWords(missing);
}
```

---

### 2.3 Modify `Macronizer.macronize()` Pipeline

**File:** `src/core/Macronizer.ts`

```typescript
async macronize(text: string): Promise<MacronizeResult> {
  const startTime = performance.now();

  // Check cache...
  // ...

  // Step 1: Tokenize
  const tokenization = new Tokenization(text, { preserveWhitespace: true });

  // Step 1.5: Split enclitics (returns new word forms)
  const splitWordForms = await tokenization.splitEnclitics(this.wordlistEngine);

  // Step 1.75: PRE-ANALYZE unknown words with Morpheus (NEW)
  const allWordForms = [
    ...tokenization.allWordForms(),
    ...splitWordForms
  ];
  await this.wordlistEngine.ensureAnalyzed(allWordForms);

  // Step 2: POS Tagging
  if (this.useWasm && (this.tagger as WasmTagger).isReady()) {
    await tokenization.tagWithWasm(this.tagger as WasmTagger);
  } else {
    // fallback...
  }

  // Step 3: Add lemmas
  tokenization.addLemmas(this.lemmaEngine);

  // Step 4: Get accents (wordlist now includes Morpheus entries)
  await tokenization.getAccents(this.wordlistEngine, this.endingEngine);

  // Step 5: Macronize
  tokenization.macronize(true, true, false, false, this.endingEngine);

  // ...
}
```

---

### 2.4 Remove Dead Code

**File:** `src/core/Macronizer.ts`

- Delete `macronizeToken()` (lines 275–332) — uses per-token Morpheus, not batch
- Delete `applyMacronization()` (lines 260–269) — calls `macronizeToken()`, unused
- Verify no other code calls these methods

---

## 3. Implementation Checklist

### Phase 1: Enhance WordlistEngine
- [ ] Add `cleanLemma(lemma: string): string` helper
- [ ] Rewrite `analyzeUnknownWords()`:
  - Process all Morpheus analyses per word
  - Group by `(lemma, ldtTag)`
  - Select best accented per group (max `v/j/J` count)
  - Apply `trans` workaround
  - Create one `WordlistEntry` per group
  - Call `addEntry()` for each
- [ ] Add `ensureAnalyzed(wordForms: string[]): Promise<void>`
- [ ] Verify `analysisToLdtTag()` correctness

### Phase 2: Update Macronizer
- [ ] Modify `Macronizer.macronize()` to call `ensureAnalyzed()` after `splitEnclitics()`
- [ ] Capture return value from `splitEnclitics()` and include in `allWordForms`
- [ ] Remove `macronizeToken()` and `applyMacronization()`
- [ ] Verify no other dependencies

### Phase 3: Validation
- [ ] Run `test-algorithms-compare.html` with full wordlist
- [ ] Compare to `dist/output.txt`
- [ ] Test: `minime`, `eos`, `hi`, `matrona`
- [ ] Ensure no regressions in Caesar 1.1

### Phase 4: Polish
- [ ] Add progress callback for Morpheus (optional)
- [ ] Update `README-BROWSER.md`
- [ ] Add unit tests for new methods

---

## 4. Expected Impact

### 4.1 Accuracy
- Unknown words get proper morphological analysis
- Multiple candidate entries → better ranking
- Should match Python accuracy **exactly**

### 4.2 Performance
- One-time Morpheus cost per unknown word (cached)
- No per-request Morpheus after first run
- Batch analysis efficient

### 4.3 Compatibility
- Fully backward compatible
- Morpheus only for missing words
- Matches Python behavior

---

## 5. Risks & Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| `analysisToLdtTag()` imperfect | High | Add unit tests; compare to Python |
| DB bloat | Low | Limited parses per word |
| `trans` workaround missing | Medium | Implement exactly as Python |
| Batch too large | Low | Chunk if needed |
| Duplicate entries | Low | Unique key prevents duplicates |

---

## 6. Testing Strategy

1. Unit tests for `cleanLemma()`, `analysisToLdtTag()`, `ensureAnalyzed()`
2. Integration: `test-algorithms-compare.html`
3. Regression: Caesar 1.1
4. Performance: text with many rare words

---

## 7. References

- Python: `latin_macronizer/wordlist.py` (lines 70–166)
- Python: `latin_macronizer/postags.py` (lines 419–537, 254–385)
- TypeScript: `src/analysis/WordlistEngine.ts`
- TypeScript: `src/core/Macronizer.ts`
- TypeScript: `src/analysis/MorpheusAnalyzer.ts`

---

**Plan created by:** Kilo Code  
**Status:** Ready for implementation
