# Полный план завершения порта Latin Macronizer

## Текущий статус
- ✅ **Ядро готово на 98%**: токенизация, теггинг (RFTagger WASM), лемматизация, wordlist (IndexedDB), паттерны окончаний, DP alignment
- ✅ **Критические баги исправлены**: enclitic property names, HTML в detokenize
- ✅ **Тест `test-algorithms-compare.html` должен проходить** (после hard refresh)

---

## Фаза 1: Завершение недоделанных алгоритмов (Приоритет: HIGH)

### 1.1 Полная реализация `dividenda` и enclitic splitting
**Status:** Частично реализовано, есть placeholder для сложных случаев

**Задачи:**
- [ ] **Исправить логику split для `dividenda` слов**:
  - Сейчас в `Tokenization.splitEnclitics` есть блок `else if (asciiLower in Tokenization.dividenda)` который делит слово на две части: stem + rest
  - Но для сложных составных слов (например, `unusquisque` = `unus` + `quisque`) этого недостаточно
  - Нужно реализовать **многоэтапный split**: после первого деления, вторую часть проверить на наличие ещё одного enclitic
  - Пример: `unusquisque` → `unus` + `quisque` → `qui` + `sque` (но `quisque` само является `dividendum`?)
  - **Действие**: Изучить Python `tokenization.py` метод `split_enclitics` для `dividenda` слов

- [ ] **Добавить недостающие `dividenda` entries**:
  - Проверить, все ли слова из Python `tokenization.dividenda` присутствуют в TS
  - Добавить отсутствующие (смотри `latin_macronizer/tokenization.py` строки ~40-60)
  - Ключи: `nequid`, `attamen`, `unusquisque`, `unaquaeque`, `unumquodque`, `uniuscuiusque`, `uniuscujusque`, `unicuique`, `unumquemque`, `unamquamque`, `unoquoque`, `unaquaque`, `cuiusmodi`, `cujusmodi`, `quojusmodi`, `eiusmodi`, `ejusmodi`, `huiuscemodi`, `hujuscemodi`, `huiusmodi`, `hujusmodi`, `istiusmodi`, `nullomodo`, `quodammodo`, `nudiustertius`, `nonnisi`, `plusquam`, `proculdubio`, `quamplures`, `quamprimum`, `quinetiam`, `uerumetiam`, `verumetiam`, `verumtamen`, `uerumtamen`, `paterfamilias`, `patrisfamilias`, `patremfamilias`, `patrifamilias`, `patrefamilias`, `patresfamilias`, `patrumfamilias`, `patribusfamilias`, `materfamilias`, `matrisfamilias`, `matremfamilias`, `matrifamilias`, `matrefamilias`, `matresfamilias`, `matrumfamilias`, `matribusfamilias`, `respublica`, `reipublicae`, `rempublicam`, `senatusconsultum`, `senatusconsulto`, `senatusconsulti`, `usufructu`, `usumfructum`, `ususfructus`, `supradicti`, `supradictum`, `supradictus`, `supradicto`, `seipse`, `seipsa`, `seipsum`, `seipsam`, `seipso`, `seipsos`, `seipsas`, `seipsis`, `semetipse`, `semetipsa`, `semetipsum`, `semetipsam`, `semetipso`, `semetipsos`, `semetipsas`, `semetipsis`, `teipsum`, `temetipsum`, `vosmetipsos`, `idipsum`

- [ ] **Протестировать на реальных примерах**:
  - `unusquisque` → `unus` + `quisque` → `qui` + `sque`?
  - `quibuscum` → `qui` + `bus` + `cum` (уже должно работать через generic split)
  - `necnon` → `ne` + `c` + `non` (уже реализовано специально)
  - `paterfamilias` → `pater` + `familias` (оба слова известны)
  - `respublica` → `res` + `publica`

- [ ] **Убедиться, что split происходит только для**:
  1. Слов, которых нет в wordlist (`!exists`)
  2. Слов, которые в `dividenda`
  3. Слов, которые в `specialEncliticWords` (`nec`, `neque`, `necnon`, `seque`, `seseque`, `quique`, `mecumque`, `tecumque`, `secumque`)
  4. **Но не для** обычных `-que` слов, которые есть в wordlist (например, `atque`)

### 1.2 Флаг `alsomaius` (macron before j)
**Status:** Реализован в `alignMacronized.ts`, но не тестирован

**Задачи:**
- [ ] **Найти тестовые слова с `j` после короткого гласного**:
  - Примеры: `major` (от `magnus` + `-ior`), `sapius` → `sapjius`?
  - Префиксы из `prefixesWithShortJ`: `bij`, `fidej`, `Foroj`, `foroj`, `ju_rej`, `multij`, `praej`, `quadrij`, `rej`, `retroj`, `se_mij`, `sesquij`, `u_nij`, `introj`
  - Слова: `rejoice`? (но это не латинское), `major`, `fidejussor`?

- [ ] **Протестировать сценарий**:
  - Вход: слово с `j` (например, `fidejussor`)
  - `alsomaius = true` → должен добавить macron перед `j` если гласный перед `j` короткий и слово **не** начинается с префикса из `prefixesWithShortJ`
  - Результат: `fide_jussor` → `fidējussor`? (нужно проверить в Python)

- [ ] **Убедиться, что флаг корректно обрабатывается**:
  - В `Macronizer.macronize()` передаётся `alsomaius: true`
  - В `alignMacronized` применяется только если `domacronize && alsomaius`
  - Префиксы из `prefixesWithShortJ` исключаются из трансформации

### 1.3 Scansion (определение метра стихов)
**Status:** Не портирован

**Задачи:**
- [ ] **Изучить Python `scansion.py` и `meters.py`**:
  - `scansion.py` использует `meters.py` для определения метра (ямб, дактиль, хорей и т.д.)
  - Алгоритм: разбить на стопы, проверить длину гласных, сравнить с шаблонами

- [ ] **Порт `meters.py` → TS**:
  - Создать `src/analysis/Meters.ts`
  - Перенести классы `Meter` и конкретные метры (Iambic, Dactylic, etc.)
  - Алгоритм scansion: определить длину гласных (уже есть macronized текст), разбить на стопы, сравнить с паттерном

- [ ] **Порт `scansion.py` → TS**:
  - Создать `src/analysis/Scansion.ts`
  - Функция `scan(text: string, meter?: string): ScanResult`
  - Возвращает: метка метра, список стоп с ударениями, confidence

- [ ] **Интеграция в UI**:
  - Кнопка "Скансировать стих" в `public/index.html`
  - Выбор метра (или auto-detect)
  - Визуализация: `– u u | – u u | – u u` (где `–` = долгая, `u` = короткая)

---

## Фаза 2: UI / UX улучшения (Приоритет: HIGH)

### 2.1 Обновить `public/index.html` (главная страница)
**Текущее состояние:** Базовая страница с textarea, кнопкой "Macronize", выводом результата

**Необходимые изменения:**
- [ ] **Использовать `WasmTagger` по умолчанию** (сейчас `useWasm: false` в коде, нужно `true`)
- [ ] **Добавить загрузку wordlist из файла**:
  - Уже есть input[type="file"] и кнопка "Load Wordlist from File" в `test-algorithms-compare.html`
  - Перенести эту логику в `public/index.html`
  - Показывать прогресс: "Loaded 150000 of 3500000..."
- [ ] **Прогресс-бар загрузки wordlist**:
  - В `WordlistEngine.loadFromText` уже есть `onProgress(count)`
  - Подключить callback к UI: обновлять `<progress>` элемент или текст
- [ ] **Отображать детали токенов в таблице**:
  - Как в `test-algorithms-compare.html`: столбцы #, Original, Tag, Lemma, Accented Candidates, Macronized, Flags
  - Добавить toggle "Show token details" (чтобы не перегружать UI)
- [ ] **Подсветка неизвестных/неоднозначных слов**:
  - CSS классы `.unknown` (жёлтый фон) и `.ambig` (голубой фон)
  - В `detokenize` нужно вернуть поддержку `markAmbigs` параметра (сейчас убрал)
  - Или обернуть в `<span>` на уровне UI после `macronize()`
- [ ] **Кнопка "Сравнить с Python"**:
  - Если запущен Python бэкенд (на localhost:5000), отправить запрос и показать diff
  - Или просто ссылка на `test-algorithms-compare.html`

### 2.2 Улучшить `test-algorithms-compare.html`
**Текущее состояние:** Работает, но нет настройки флагов

**Задачи:**
- [ ] **Добавить UI элементы для управления флагами**:
  - Checkbox: `domacronize` (по умолчанию checked)
  - Checkbox: `alsomaius` (по умолчанию unchecked)
  - Checkbox: `performutov` (u→v, по умолчанию unchecked)
  - Checkbox: `performitoj` (i→j, по умолчанию unchecked)
  - Select: `endingEngine` включить/выключить

- [ ] **Показывать diff посимвольно**:
  - Уже есть "First difference at character X"
  - Добавить выделение различий в двух строках (красный/зелёный)

- [ ] **Кнопка "Load Python reference"**:
  - Если Python сервер запущен на `http://localhost:5000/ macronize`, получить эталонный output
  - Сравнить автоматически

- [ ] **Сохранять настройки в localStorage**:
  - Чтобы при перезагрузке не сбрасывались флаги

### 2.3 Мобильная адаптация и темы
- [ ] **Responsive CSS**:
  - `@media (max-width: 768px)` для textarea и таблицы
  - Таблица токенов должна скроллиться горизонтально
  - Кнопки в колонку на узких экранах

- [ ] **Тёмная тема** (опционально):
  - Переключатель в углу
  - CSS переменные: `--bg-color`, `--text-color`, `--accent-color`
  - Сохранять выбор в `localStorage`

---

## Фаза 3: Производительность и надёжность (Приоритет: MEDIUM)

### 3.1 Оптимизация загрузки wordlist
**Проблема:** 3.5M записей загружаются 3-4 минуты

**Решения:**
- [ ] **Пакетная загрузка с прогрессом** (уже есть, но нужно подключить UI)
- [ ] **Версионирование wordlist**:
  - Добавить поле `version` в `WordlistEngine`
  - При загрузке проверять хэш файла или размер
  - Если версия не изменилась, пропустить загрузку
- [ ] **Ленивая загрузка Morpheus WASM**:
  - Сейчас Morpheus инициализируется при создании `Macronizer`
  - Изменить: инициализировать только при первом неизвестном слове
  - Добавить флаг `morpheusInitialized` и метод `ensureMorpheus()`

### 3.2 Оптимизация запросов к IndexedDB
**Проблема:** Для каждого токена делается отдельный `getAllEntries` (N+1 запрос)

**Решение:**
- [ ] **Пакетный lookup**:
  - В `getAccents` собрать все уникальные `wordformLower`
  - Один запрос `getAllEntries` для каждого уникального слова
  - Кэшировать результаты в `Map<string, WordlistEntry[]>`

- [ ] **Индексирование по wordform + tag**:
  - Сейчас ключ objectStore: `['wordform', 'tag', 'lemma']`
  - Для lookup по wordform только используется индекс 'wordform' – это нормально
  - Но можно добавить составной индекс `wordform+tag` для быстрого точного совпадения

### 3.3 Обработка ошибок
- [ ] **WASM не загрузился**:
  - Показать понятное сообщение: "RFTagger model not loaded. Please check console."
  - Fallback на `FallbackTagger` (правила окончаний)

- [ ] **Wordlist недоступен**:
  - Если fetch `latin_macronizer/macrons.txt` вернул 404, показать кнопку загрузки файла
  - Авто-ретрай с экспоненциальной задержкой

- [ ] **IndexedDB ошибки** (квота, corruption):
  - Ловить `onerror` и предлагать очистить базу
  - Кнопка "Clear wordlist cache"

---

## Фаза 4: Тестирование (Приоритет: MEDIUM)

### 4.1 Юнит-тесты (Jest)
**Настройка:**
- Уже есть `jest.config.js` – проверить, что работает
- Добавить `ts-jest` если нужно

**Тест-файлы:**
- [ ] `tests/splitEnclitic.test.ts`:
  - `splitEnclitic('minimeque')` → `['minime', 'que']`
  - `splitEnclitic('atque')` → `null` (если `atque` в wordlist)
  - `splitEnclitic('quibuscum')` → `['quibus', 'cum']`
  - `splitEnclitic('necnon')` → специальный случай → `['ne', 'c', 'non']`
  - `splitEnclitic('unusquisque')` → `['unus', 'quisque']` (если `quisque` в `dividenda`)

- [ ] `tests/tagDistance.test.ts`:
  - Разные форматы тегов (17-char RFTagger, 9-char LDT, 12-char)
  - Сравнение nomen vs verb (игнорирование tense/mood/voice)
  - `tagDistance('n---s-------f-n--', 'n---p-------f-n--')` = 1 (number differs)

- [ ] `tests/normalizeTag.test.ts`:
  - `normalizeTag('n.-.s.-.-.-.f.b.-')` → `'n-s---fn-'`
  - `normalizeTag('n---s-------f-n--')` → уже LDT, возвращает как есть

- [ ] `tests/analysisToLdtTag.test.ts`:
  - Morpheus analysis → LDT tag
  - Пример: `{partOfSpeech: 'noun', number: 'sing', gender: 'fem', case: 'nom'}` → `'n-s---fn-'`

- [ ] `tests/alignMacronized.test.ts`:
  - Простые случаи: `alignMacronized('amicus', 'am_i_cus')` → `'amīcus'` (с macron)
  - С `alsomaius`: `alignMacronized('fidejussor', 'fide_jussor', {alsomaius: true})` → `'fidējussor'`?
  - С `performutov`: `alignMacronized('uulnus', 'v_ulnus', {performutov: true})` → `'vūlnus'`?

- [ ] `tests/WordlistEngine.test.ts`:
  - `lookup('minime', tag)` возвращает правильный accented
  - `getAllEntries('matrona')` возвращает все варианты
  - `addEntry` и `addEntries` работают

### 4.2 Интеграционные тесты
- [ ] **Сравнение с Python для целого корпуса**:
  - Взять текст из `caesar-input.txt` (Gallic War)
  - Запустить Python macronizer, сохранить output
  - Запустить TS macronizer через `test-compare.html` или Node script
  - Сравнить посимвольно, отчет о различиях

- [ ] **Автоматический скрипт сравнения**:
  - `tests/compare-with-python.sh`:
    ```bash
    python latin_macronizer/macronizer.py < caesar-input.txt > python-output.txt
    node dist/cli.js < caesar-input.txt > ts-output.txt
    diff -u python-output.txt ts-output.txt
    ```
  - Или HTML-страница, которая делает запрос к Python бэкенду

### 4.3 Кросс-браузерное тестирование
- [ ] Chrome (latest)
- [ ] Firefox (latest)
- [ ] Safari (latest)
- [ ] Edge (latest)
- Проверить:
  - IndexedDB работает
  - WASM загружается
  - Отображение Unicode macrons (ā, ē, ī, ō, ū, ȳ)

---

## Фаза 5: Документация (Приоритет: MEDIUM)

### 5.1 `README_PORT.md`
**Структура:**
```markdown
# Latin Macronizer – Browser Port

## Status
- Core: ✅ 98% complete
- Algorithms: fully ported
- UI: basic, needs improvements

## Quick Start
```bash
npm install
npm run build
npx serve .
# Open http://localhost:3000
```

## Architecture
```
Input Text → Tokenization → Split Enclitics → WASM Tagging → Lemmas → Wordlist Lookup → DP Alignment → Output
     ↓            ↓               ↓                ↓           ↓          ↓              ↓
  Token[]   Token[] (+stem)   Tag[]          Lemma[]   Entry[]   Accented[]   Macronized[]
```

## Components
- `Tokenization`: regex-based, preserves whitespace
- `WasmTagger`: RFTagger WASM (17-char → 9-char LDT)
- `LemmaEngine`: pre-compiled lemma dictionary
- `WordlistEngine`: IndexedDB, compound key
- `EndingPatternEngine`: pattern matching for unknowns
- `MorpheusAnalyzer`: WASM morphological analysis
- `alignMacronized`: DP edit distance

## Known Limitations
- `dividenda` split not fully implemented for complex compounds
- `alsomaius` flag untested
- Scansion not ported
- Wordlist loading slow (3-4 min for 3.5M entries)

## Development
- Build: `npm run build` (tsc + fix-imports)
- WASM models: `public/wasm/rftagger.js` + `.wasm`, `public/wasm/cruncher.js` + `.wasm`
- Data: `latin_macronizer/macrons.txt`, `lemmas.json`, `endings.json`
```

### 5.2 JSDoc комментарии
- [ ] Добавить `/** ... */` для всех публичных классов и методов
- [ ] Описать параметры, возвращаемые значения, исключения
- [ ] Примеры использования

### 5.3 Руководство пользователя
- [ ] `USER_GUIDE.md`:
  - Как macronize текст
  - Как интерпретировать таблицу токенов
  - Что означают флаги ambiguous/unknown
  - Как загрузить свой wordlist

### 5.4 Руководство разработчика
- [ ] `DEVELOPER_GUIDE.md`:
  - Архитектурная диаграмма (Mermaid)
  - Как добавить новое слово в wordlist
  - Как пересобрать WASM модели
  - Как добавить поддержку нового языка

---

## Фаза 6: Production build и деплой (Приоритет: LOW)

### 6.1 Настройка сборки
- [ ] **Vite для production build**:
  - Уже есть `vite.config.js` – проверить, что работает
  - Настроить `build` команду в `package.json`: `vite build`
  - Output в `dist/` (уже есть)

- [ ] **Минификация**:
  - Vite по умолчанию минифицирует в production
  - Проверить размер файлов:
    - `rftagger.wasm` (~10 MB?) – может быть, сжать?
    - `cruncher.wasm` (~5 MB?)
    - JS бандлы

- [ ] **Source maps**:
  - `vite.config.js`: `build: { sourcemap: true }`
  - Для отладки в production

### 6.2 Docker
- [ ] **Dockerfile для статического сервера**:
  ```dockerfile
  FROM nginx:alpine
  COPY dist/ /usr/share/nginx/html/
  EXPOSE 80
  CMD ["nginx", "-g", "daemon off;"]
  ```

- [ ] **docker-compose.yml**:
  ```yaml
  version: '3'
  services:
    web:
      build: .
      ports:
        - "80:80"
    python-api:  # опционально, для сравнения
      build: ./python-backend
      ports:
        - "5000:5000"
  ```

### 6.3 Хостинг
- [ ] **GitHub Pages**:
  - Настроить GitHub Actions для деплоя в `gh-pages` ветку
  - `.github/workflows/deploy.yml`

- [ ] **Netlify / Vercel**:
  - Подключить репозиторий
  - Автоматический деплой при пуше

### 6.4 CI/CD
- [ ] **GitHub Actions**:
  - `.github/workflows/ci.yml`:
    - `npm install`
    - `npm run build`
    - `npm test` (если есть тесты)
    - Запуск lint (ESLint)
  - `.github/workflows/deploy.yml`:
    - На `push` в `main` → деплой в `gh-pages`

---

## Фаза 7: Дополнительные фичи (Приоритет: LOW)

### 7.1 Скансирование стихов
- [ ] Порт `scansion.py` и `meters.py`
- [ ] UI: textarea для стиха, кнопка "Скансировать"
- [ ] Вывод: мета-данные (метр, стопы, ударения)

### 7.2 Поддержка греческого
- [ ] Оценка: отдельный wordlist (`greek_macrons.txt`), отдельные правила
- [ ] Если нужен – создать отдельный проект или модуль

### 7.3 Экспорт результатов
- [ ] Кнопка "Download TXT" – скачивать macronized текст
- [ ] Кнопка "Export JSON" – детали по каждому токену (текст, тег, лемма, кандидаты)
- [ ] Формат JSON:
  ```json
  {
    "original": "...",
    "macronized": "...",
    "tokens": [
      {
        "original": "Gallos",
        "macronized": "Gallōs",
        "tag": "n---p-------m-a--",
        "lemma": "gallus",
        "candidates": ["gallo_s", "Gallo_s"],
        "isAmbiguous": true
      }
    ]
  }
  ```

### 7.4 REST API (Node.js сервер)
- [ ] Создать `server/` с Express.js
- [ ] Endpoint `POST /api/macronize`:
  ```json
  { "text": "Gallia est omnis..." }
  ```
  Response:
  ```json
  { "macronized": "...", "tokens": [...] }
  ```
- [ ] CORS для кросс-доменных запросов
- [ ] Документация API (Swagger/OpenAPI)

---

## Фаза 8: Сообщество и сопровождение

### 8.1 GitHub Issues
- [ ] Создать шаблоны:
  - `bug_report.md`
  - `feature_request.md`
  - `question.md`

### 8.2 Contribution guidelines
- [ ] `CONTRIBUTING.md`:
  - Как запустить dev-среду
  - Code style (Prettier, ESLint)
  - Процесс пулл-реквестов
  - Тестирование перед коммитом

### 8.3 Лицензия
- [ ] Проверить совместимость:
  - Python оригинал: ?
  - WASM модели: RFTagger (GPL?), Morpheus (GPL?)
  - Наш код: MIT (указано в `package.json`?)

### 8.4 Контакты
- [ ] `SUPPORT.md`:
  - Email
  - GitHub Discussions
  - Matrix/Discord канал (если есть)

---

## Порядок реализации (рекомендуемый)

### Неделя 1-2: Критические алгоритмы
1. Завершить `dividenda` split (проверить на `unusquisque`, `paterfamilias`)
2. Протестировать `alsomaius` (найти реальные примеры)
3. Написать юнит-тесты для `splitEnclitic`

### Неделя 3-4: UI улучшения
1. Обновить `public/index.html`:
   - WASM по умолчанию
   - Загрузка файла + прогресс-бар
   - Таблица токенов
2. Улучшить `test-algorithms-compare.html` (флаги, diff)
3. Сделать responsive CSS

### Неделя 5-6: Производительность
1. Пакетный lookup в IndexedDB
2. Ленивая загрузка Morpheus
3. Прогресс-бар загрузки wordlist в UI

### Неделя 7-8: Тестирование и документация
1. Написать юнит-тесты (основные функции)
2. Интеграционный тест с Caesar's Gallic War
3. Обновить `README_PORT.md`
4. Добавить JSDoc

### Неделя 9-10: Деплой и финализация
1. Production build (Vite)
2. Docker образ
3. GitHub Pages
4. CI/CD
5. Финализация документации

---

## Оценка усилий

| Задача | Сложность | Время (чел-часы) |
|--------|-----------|------------------|
| Завершить `dividenda` | Medium | 8-12 |
| Протестировать `alsomaius` | Low | 2-4 |
| Порт `scansion` | High | 16-24 |
| UI улучшения (главная страница) | Medium | 12-16 |
| `test-algorithms` улучшения | Low | 4-6 |
| Responsive CSS | Low | 4-6 |
| Пакетный lookup IDB | Medium | 6-8 |
| Ленивая загрузка Morpheus | Low | 2-4 |
| Юнит-тесты (основные) | Medium | 8-12 |
| Интеграционные тесты | Medium | 6-8 |
| Документация | Medium | 8-12 |
| Production build | Low | 2-4 |
| Docker | Low | 2-4 |
| CI/CD | Low | 2-4 |
| **Итого** | | **~90-130 часов** |

---

## Риски и зависимости

| Риск | Вероятность | Влияние | Митигация |
|------|-------------|---------|-----------|
| `dividenda` split сложнее, чем кажется | Medium | High | Изучить Python код подробно, написать тесты для каждого слова |
| `alsomaius` не имеет примеров в тестовом тексте | High | Low | Найти латинские слова с `j` после короткого гласного из реальных текстов |
| Scansion требует глубокого знания метрики | Medium | Medium | Консультация с филологом, использовать Python как референс |
| IndexedDB performance на больших данных | Medium | Medium | Пакетные операции, индексы, Web Worker для фоновой загрузки |
| WASM размер файлов слишком велик для браузера | Low | Medium | Сжатие (gzip/brotli), lazy loading, прогресс-бар |
| Кросс-браузерные проблемы (Safari) | Medium | Low | Тестирование, полифиллы при необходимости |

---

## Критерии завершения (Definition of Done)

- [ ] **Функционально**: Все алгоритмы из Python работают идентично (проверено на Caesar's Gallic War)
- [ ] **UI**: Главная страница удобна, показывает прогресс, детали токенов, подсветку
- [ ] **Производительность**: Загрузка wordlist < 2 мин (с прогресс-баром), макронизация < 1 сек на 100 слов
- [ ] **Тесты**: Юнит-тесты покрывают >70% кода, интеграционные тесты проходят
- [ ] **Документация**: README, JSDoc, guides обновлены
- [ ] **Деплой**: Production build работает, Docker образ собирается, GitHub Pages деплоится
- [ ] **Сообщество**: Issue templates, CONTRIBUTING.md, лицензия проверена

---

## Примечания

1. **Приоритеты**: Сначала завершить `dividenda` и `alsomaius` (это алгоритмические дыры), затем UI, затем оптимизация.
2. **Scansion** – отдельная большая задача, может быть вынесена в отдельный спринт.
3. **Греческий** – если нужен, потребует значительных усилий (новый wordlist, новые правила).
4. **API** – если нужен REST, нужно создать отдельный Node.js сервер (или использовать Cloudflare Workers для edge-deploy).

---

*Последнее обновление: 2025-05-05*
*Автор: Kilo Code (AI Assistant)*
